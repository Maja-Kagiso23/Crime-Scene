package crimescene.classification;

import crimescene.util.Graph;

import java.awt.image.BufferedImage;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.Map;

/**
 * A classifier that identifies objects in crime scene images using superpixels and region adjacency graphs.
 * The classifier can identify weapons, tools, and blood stains in images.
 *
 * @author Kagiso Maja
 */
public class ObjectClassifier {
    private static final int TARGET_SUPERPIXELS = 500;      // was 100
    private static final double COMPACTNESS = 20.0;         // SLIC "m" for RGB distances
    private static final boolean DEBUG = Boolean.getBoolean("crimescene.debug");

    // Region merging / object tests (tune these on your own images)
    private static final double MERGE_SIMILARITY = 0.92;     // adjacent cells merge above this edge similarity
    private static final double MIN_OBJECT_FRACTION = 0.01;  // weapon/tool must cover >= 1% of the image
    private static final double MAX_OBJECT_FRACTION = 0.25;  // ... and <= 25% (bigger = ground)
    private static final double OBJECT_CONTRAST = 0.85;      // boundary similarity above this = blends in
    private static final double WEAPON_ELONGATION = 1.5;
    private static final double TOOL_ELONGATION = 2.5;

    private BufferedImage image;
    private Graph<SuperPixelNode, SimilarityEdge> rag;
    private Map<Integer, String> objectClasses;

    // NEW: kept as fields so buildRAG can use real pixel adjacency
    private int[][] labels;                  // labels[x][y] = superpixel index
    private int cellArea;                    // approx. pixels per superpixel
    private List<Set<Integer>> adjacency;    // adjacency.get(i) = indices adjacent to i

    /**
     * Constructs an ObjectClassifier with predefined object classes.
     */
    public ObjectClassifier() {
        objectClasses = new HashMap<>();
        objectClasses.put(1, "Weapon");
        objectClasses.put(2, "Tool");
        objectClasses.put(3, "Blood");
    }

    /**
     * Classifies objects in the input image and returns an annotated version.
     */
    public BufferedImage classifyObjects(BufferedImage inputImage) {
        this.image = inputImage;
        System.out.println("[ObjectClassifier] region-merging version, image "
                + inputImage.getWidth() + "x" + inputImage.getHeight());
        List<SuperPixel> superpixels = createSuperPixels(image);
        buildRAG(superpixels);
        classifySuperpixels();

        int weapons = 0, tools = 0, bloods = 0;
        for (Region r : regions) {
            if (r.className.equals("Weapon")) weapons++;
            else if (r.className.equals("Tool")) tools++;
            else if (r.className.equals("Blood")) bloods++;
        }
        System.out.println("[ObjectClassifier] regions: " + regions.size() + " total, "
                + weapons + " weapon, " + tools + " tool, " + bloods + " blood");
        return generateOutputImage();
    }

    // ------------------------------------------------------------------
    // CHANGED: createSuperPixels  (windowed SLIC, proper distance, labels kept)
    // ------------------------------------------------------------------
    /**
     * Creates superpixels from the input image using a SLIC-style algorithm.
     * Each cluster only competes for pixels in a 2S x 2S window around its centre,
     * and colour/space are combined with the standard SLIC formula, so clusters stay
     * spatially compact instead of collecting same-coloured pixels from all over the image.
     */
    private List<SuperPixel> createSuperPixels(BufferedImage image) {
        final int w = image.getWidth();
        final int h = image.getHeight();
        final int gridSize = Math.max(4, (int) Math.sqrt((double) w * h / TARGET_SUPERPIXELS));
        cellArea = gridSize * gridSize;

        int[] pix = image.getRGB(0, 0, w, h, null, 0, w); // pix[y * w + x]

        List<SuperPixel> superpixels = new ArrayList<>();
        for (int y = gridSize / 2; y < h; y += gridSize) {
            for (int x = gridSize / 2; x < w; x += gridSize) {
                int rgb = pix[y * w + x];
                SuperPixel sp = new SuperPixel();
                sp.centerX = x;
                sp.centerY = y;
                sp.r = (rgb >> 16) & 0xFF;
                sp.g = (rgb >> 8) & 0xFF;
                sp.b = rgb & 0xFF;
                sp.pixels = new ArrayList<>();
                superpixels.add(sp);
            }
        }

        labels = new int[w][h];
        for (int[] col : labels) Arrays.fill(col, -1);
        double[][] dist = new double[w][h];

        for (int iter = 0; iter < 10; iter++) {
            for (double[] col : dist) Arrays.fill(col, Double.MAX_VALUE);

            // Assignment step: each centre only looks at pixels within +-gridSize
            for (int i = 0; i < superpixels.size(); i++) {
                SuperPixel sp = superpixels.get(i);
                int x0 = Math.max(0, sp.centerX - gridSize);
                int x1 = Math.min(w - 1, sp.centerX + gridSize);
                int y0 = Math.max(0, sp.centerY - gridSize);
                int y1 = Math.min(h - 1, sp.centerY + gridSize);

                for (int y = y0; y <= y1; y++) {
                    for (int x = x0; x <= x1; x++) {
                        int rgb = pix[y * w + x];
                        int dr = sp.r - ((rgb >> 16) & 0xFF);
                        int dg = sp.g - ((rgb >> 8) & 0xFF);
                        int db = sp.b - (rgb & 0xFF);
                        double dc = Math.sqrt(dr * dr + dg * dg + db * db);

                        double dx = sp.centerX - x;
                        double dy = sp.centerY - y;
                        double ds = Math.sqrt(dx * dx + dy * dy);

                        double a = dc / COMPACTNESS;
                        double b = ds / gridSize;
                        double d = a * a + b * b; // squared is enough for comparison

                        if (d < dist[x][y]) {
                            dist[x][y] = d;
                            labels[x][y] = i;
                        }
                    }
                }
            }

            // Reset accumulators
            for (SuperPixel sp : superpixels) {
                sp.pixels.clear();
                sp.sumX = sp.sumY = sp.sumR = sp.sumG = sp.sumB = sp.count = 0;
            }

            // Accumulate
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int label = labels[x][y];
                    if (label < 0) continue;
                    SuperPixel sp = superpixels.get(label);
                    int rgb = pix[y * w + x];
                    sp.pixels.add(new Point(x, y));
                    sp.sumX += x;
                    sp.sumY += y;
                    sp.sumR += (rgb >> 16) & 0xFF;
                    sp.sumG += (rgb >> 8) & 0xFF;
                    sp.sumB += rgb & 0xFF;
                    sp.count++;
                }
            }

            // Update centres and bounding boxes
            for (SuperPixel sp : superpixels) {
                if (sp.count > 0) {
                    sp.centerX = sp.sumX / sp.count;
                    sp.centerY = sp.sumY / sp.count;
                    sp.r = sp.sumR / sp.count;
                    sp.g = sp.sumG / sp.count;
                    sp.b = sp.sumB / sp.count;

                    sp.minX = Integer.MAX_VALUE;
                    sp.minY = Integer.MAX_VALUE;
                    sp.maxX = Integer.MIN_VALUE;
                    sp.maxY = Integer.MIN_VALUE;
                    for (Point p : sp.pixels) {
                        sp.minX = Math.min(sp.minX, p.x);
                        sp.minY = Math.min(sp.minY, p.y);
                        sp.maxX = Math.max(sp.maxX, p.x);
                        sp.maxY = Math.max(sp.maxY, p.y);
                    }
                } else {
                    // empty cluster: give it a harmless box so nothing reads MAX_VALUE
                    sp.minX = sp.maxX = sp.centerX;
                    sp.minY = sp.maxY = sp.centerY;
                }
            }
        }

        // NEW: fill the texture features (per-channel variance) that were never computed
        for (SuperPixel sp : superpixels) {
            if (sp.count == 0) continue;
            double vr = 0, vg = 0, vb = 0;
            for (Point p : sp.pixels) {
                int rgb = pix[p.y * w + p.x];
                double dr = ((rgb >> 16) & 0xFF) - sp.r;
                double dg = ((rgb >> 8) & 0xFF) - sp.g;
                double db = (rgb & 0xFF) - sp.b;
                vr += dr * dr;
                vg += dg * dg;
                vb += db * db;
            }
            sp.textureFeatures[0] = vr / sp.count;
            sp.textureFeatures[1] = vg / sp.count;
            sp.textureFeatures[2] = vb / sp.count;
        }

        return superpixels;
    }

    // ------------------------------------------------------------------
    // CHANGED: buildRAG  (edges from real pixel adjacency; areAdjacent() is deleted)
    // ------------------------------------------------------------------
    /**
     * Builds a Region Adjacency Graph (RAG). Two superpixels are adjacent only if
     * some pixel of one directly touches a pixel of the other.
     */
    private void buildRAG(List<SuperPixel> superpixels) {
        rag = new Graph<>();
        int n = superpixels.size();
        adjacency = new ArrayList<>(n);

        for (int i = 0; i < n; i++) {
            rag.addNode(new SuperPixelNode(i, superpixels.get(i)));
            adjacency.add(new HashSet<>());
        }

        int w = labels.length;
        int h = labels[0].length;
        Set<Long> seen = new HashSet<>();

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int a = labels[x][y];
                if (a < 0) continue;
                if (x + 1 < w) linkIfNew(a, labels[x + 1][y], seen, superpixels);
                if (y + 1 < h) linkIfNew(a, labels[x][y + 1], seen, superpixels);
            }
        }
    }

    /** NEW helper: creates one edge per touching pair of superpixels. */
    private void linkIfNew(int a, int b, Set<Long> seen, List<SuperPixel> superpixels) {
        if (b < 0 || a == b) return;
        int lo = Math.min(a, b);
        int hi = Math.max(a, b);
        long key = (long) lo * superpixels.size() + hi;
        if (!seen.add(key)) return;

        SuperPixelNode n1 = (SuperPixelNode) rag.getNode(lo);
        SuperPixelNode n2 = (SuperPixelNode) rag.getNode(hi);
        double similarity = calculateSimilarity(superpixels.get(lo), superpixels.get(hi));

        SimilarityEdge edge = new SimilarityEdge(n1, n2, similarity); // sets from/to nodes
        edge.setColorSimilarity(similarity);
        rag.addEdge(n1, n2, edge);

        adjacency.get(lo).add(hi);
        adjacency.get(hi).add(lo);
    }

    /**
     * Calculates the similarity between two superpixels based on colour.
     * Range is roughly 0.37 (black vs white) to 1.0 (identical).
     */
    private double calculateSimilarity(SuperPixel sp1, SuperPixel sp2) {
        double colorDist = Math.sqrt(
            Math.pow(sp1.r - sp2.r, 2) +
            Math.pow(sp1.g - sp2.g, 2) +
            Math.pow(sp1.b - sp2.b, 2)
        );
        return 1.0 / (1.0 + colorDist / 255.0);
    }

    // ------------------------------------------------------------------
    // Blood (per superpixel)
    // ------------------------------------------------------------------
    /** Per-pixel blood test using hue/saturation/brightness instead of fixed RGB cut-offs. */
    private boolean isBloodPixel(int rgb) {
        float[] hsb = Color.RGBtoHSB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, null);
        boolean redHue = hsb[0] < 0.04f || hsb[0] > 0.95f;  // hue near 0 degrees (red)
        return redHue && hsb[1] > 0.45f && hsb[2] > 0.15f;  // saturated and not near-black
    }

    /**
     * A superpixel is blood if at least 30% of its pixels are blood-coloured.
     * Using the fraction of pixels (not the average colour) means a small drop inside a
     * mostly-floor cell is not washed out by averaging.
     */
    private boolean isBlood(SuperPixel sp) {
        if (sp.getSize() < 20) return false;
        int hits = 0;
        for (Point p : sp.pixels) {
            if (isBloodPixel(image.getRGB(p.x, p.y))) hits++;
        }
        return hits >= 0.3 * sp.getSize();
    }

    // ------------------------------------------------------------------
    // Classification: cells -> graph regions -> labels
    // ------------------------------------------------------------------
    /** One merged group of adjacent superpixels (a connected component of the RAG). */
    private static class Region {
        final List<Integer> cells = new ArrayList<>();
        int size;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        double meanR, meanG, meanB;
        double elongation = 1.0;     // sqrt(l1/l2) from PCA: orientation-independent, 1 = round
        double contrast = 1.0;       // mean similarity to the regions around it (1 = blends in)
        boolean touchesBorder;
        boolean blood;
        String className = "Background";

        double brightness() { return (meanR + meanG + meanB) / 3.0; }
        double colorSpread() { return Math.max(meanR, Math.max(meanG, meanB)) - Math.min(meanR, Math.min(meanG, meanB)); }
    }

    private List<Region> regions;
    private int[] regionOf; // superpixel index -> index into regions (-1 if empty)

    /**
     * Step 1: label each superpixel Blood or Background from its own pixels.
     * Step 2: merge neighbours in the RAG into regions.
     * Step 3: classify whole regions (this is where weapons and tools are found).
     */
    private void classifySuperpixels() {
        for (int i = 0; i < adjacency.size(); i++) {
            SuperPixelNode node = (SuperPixelNode) rag.getNode(i);
            SuperPixel sp = node.getSuperpixel();
            node.setClassName(sp.getSize() > 0 && isBlood(sp) ? "Blood" : "Background");
        }
        buildRegions();
        classifyRegions();
    }

    /** Looks up an edge regardless of which direction the Graph class stored it in. */
    private SimilarityEdge edgeBetween(SuperPixelNode a, SuperPixelNode b) {
        SimilarityEdge e = rag.getEdge(a, b);
        return (e != null) ? e : rag.getEdge(b, a);
    }

    private int find(int[] parent, int i) {
        while (parent[i] != i) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    }

    /**
     * Union-find over the RAG: blood cells merge with adjacent blood cells; other cells
     * merge with an adjacent non-blood cell when their edge similarity is high.
     */
    private void buildRegions() {
        int n = adjacency.size();
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;

        for (int i = 0; i < n; i++) {
            SuperPixelNode a = (SuperPixelNode) rag.getNode(i);
            boolean aBlood = a.getClassName().equals("Blood");
            for (int j : adjacency.get(i)) {
                if (j < i) continue;
                SuperPixelNode b = (SuperPixelNode) rag.getNode(j);
                boolean bBlood = b.getClassName().equals("Blood");
                if (aBlood != bBlood) continue;
                SimilarityEdge e = edgeBetween(a, b);
                if (aBlood || (e != null && e.getSimilarity() > MERGE_SIMILARITY)) {
                    parent[find(parent, i)] = find(parent, j);
                }
            }
        }

        Map<Integer, Region> byRoot = new LinkedHashMap<>();
        for (int i = 0; i < n; i++) {
            SuperPixelNode node = (SuperPixelNode) rag.getNode(i);
            if (node.getSuperpixel().getSize() == 0) continue;
            Region r = byRoot.computeIfAbsent(find(parent, i), k -> new Region());
            r.cells.add(i);
            r.blood = node.getClassName().equals("Blood");
        }
        regions = new ArrayList<>(byRoot.values());

        regionOf = new int[n];
        Arrays.fill(regionOf, -1);
        for (int ri = 0; ri < regions.size(); ri++) {
            for (int c : regions.get(ri).cells) regionOf[c] = ri;
        }
        for (Region r : regions) computeRegionFeatures(r);
        for (int ri = 0; ri < regions.size(); ri++) regions.get(ri).contrast = boundaryContrast(ri);
    }

    /** Size, bounding box, mean colour and PCA elongation of a region. */
    private void computeRegionFeatures(Region r) {
        double sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, sr = 0, sg = 0, sb = 0;
        long count = 0;
        for (int c : r.cells) {
            SuperPixel sp = ((SuperPixelNode) rag.getNode(c)).getSuperpixel();
            r.minX = Math.min(r.minX, sp.minX);
            r.minY = Math.min(r.minY, sp.minY);
            r.maxX = Math.max(r.maxX, sp.maxX);
            r.maxY = Math.max(r.maxY, sp.maxY);
            for (Point p : sp.pixels) {
                sx += p.x;
                sy += p.y;
                sxx += (double) p.x * p.x;
                syy += (double) p.y * p.y;
                sxy += (double) p.x * p.y;
                int rgb = image.getRGB(p.x, p.y);
                sr += (rgb >> 16) & 0xFF;
                sg += (rgb >> 8) & 0xFF;
                sb += rgb & 0xFF;
                count++;
            }
        }
        r.size = (int) count;
        if (count == 0) return;
        r.meanR = sr / count;
        r.meanG = sg / count;
        r.meanB = sb / count;

        double mx = sx / count, my = sy / count;
        double vx = sxx / count - mx * mx;
        double vy = syy / count - my * my;
        double cxy = sxy / count - mx * my;
        double halfTrace = (vx + vy) / 2.0;
        double disc = Math.sqrt(Math.max(0, halfTrace * halfTrace - (vx * vy - cxy * cxy)));
        double l1 = halfTrace + disc;
        double l2 = Math.max(halfTrace - disc, 1e-6);
        r.elongation = Math.sqrt(l1 / l2);

        int w = image.getWidth(), h = image.getHeight();
        r.touchesBorder = r.minX <= 0 || r.minY <= 0 || r.maxX >= w - 1 || r.maxY >= h - 1;
    }

    /**
     * Mean similarity along the border between this region and the non-blood regions around it.
     * Plain ground blends in (close to 1); a distinct object does not.
     */
    private double boundaryContrast(int ri) {
        double sum = 0;
        int count = 0;
        for (int c : regions.get(ri).cells) {
            SuperPixelNode a = (SuperPixelNode) rag.getNode(c);
            for (int j : adjacency.get(c)) {
                int rj = regionOf[j];
                if (rj == ri || rj < 0 || regions.get(rj).blood) continue;
                SimilarityEdge e = edgeBetween(a, (SuperPixelNode) rag.getNode(j));
                if (e != null) {
                    sum += e.getSimilarity();
                    count++;
                }
            }
        }
        return count == 0 ? 1.0 : sum / count;
    }

    /** Assigns a class to every region and copies it onto the region's superpixel nodes. */
    private void classifyRegions() {
        double imageArea = (double) image.getWidth() * image.getHeight();
        for (Region r : regions) {
            if (r.blood) {
                r.className = "Blood";
            } else {
                double fraction = r.size / imageArea;
                if (fraction < MIN_OBJECT_FRACTION || fraction > MAX_OBJECT_FRACTION
                        || r.touchesBorder || r.contrast > OBJECT_CONTRAST) {
                    r.className = "Background";      // too small / huge / blends into the ground
                } else if (isWeaponRegion(r)) {
                    r.className = "Weapon";
                } else if (isToolRegion(r)) {
                    r.className = "Tool";
                } else {
                    r.className = "Background";
                }
            }
            for (int c : r.cells) ((SuperPixelNode) rag.getNode(c)).setClassName(r.className);

            if (DEBUG && !r.className.equals("Background") || DEBUG && r.size > 3000 && !r.blood) {
                System.out.printf("region %-10s size=%6d bright=%5.0f spread=%4.0f elong=%4.2f contrast=%4.2f border=%b%n",
                        r.className, r.size, r.brightness(), r.colorSpread(), r.elongation, r.contrast, r.touchesBorder);
            }
        }
    }

    // ------------------------------------------------------------------
    // Region-level object tests
    // ------------------------------------------------------------------
    /** Metal-looking: grey / blue-grey (low colour spread), anywhere from near-black to light. */
    private boolean isMetalColored(Region r) {
        return r.colorSpread() < 30 && r.brightness() > 15 && r.brightness() < 220;
    }

    /** Weapon: metal-coloured, clearly elongated (any orientation) and distinct from its surroundings. */
    private boolean isWeaponRegion(Region r) {
        return isMetalColored(r) && r.elongation > WEAPON_ELONGATION;
    }

    /** Tool: wooden-coloured or metal-coloured and very elongated (handle-like). */
    private boolean isToolRegion(Region r) {
        boolean wooden = r.meanR > r.meanG && r.meanG > r.meanB && r.meanB < 100
                && r.meanR > 100 && (r.meanR - r.meanB) > 50;
        return (wooden || isMetalColored(r)) && r.elongation > TOOL_ELONGATION;
    }

    // ------------------------------------------------------------------
    // Output: one box per region (not one per superpixel)
    // ------------------------------------------------------------------
    private BufferedImage generateOutputImage() {
        BufferedImage output = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = output.createGraphics();
        g2d.drawImage(image, 0, 0, null);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));

        for (Region r : regions) {
            if (r.className.equals("Background")) continue;

            Color boxColor;
            switch (r.className) {
                case "Weapon": boxColor = Color.RED; break;
                case "Tool": boxColor = Color.BLUE; break;
                case "Blood": boxColor = Color.MAGENTA; break;
                default: boxColor = Color.GRAY; break;
            }

            g2d.setColor(boxColor);
            g2d.setStroke(new BasicStroke(3));
            g2d.drawRect(r.minX, r.minY, r.maxX - r.minX, r.maxY - r.minY);

            int labelY = Math.max(15, r.minY);
            g2d.setColor(Color.WHITE);
            g2d.fillRect(r.minX, labelY - 15, g2d.getFontMetrics().stringWidth(r.className) + 4, 15);
            g2d.setColor(Color.BLACK);
            g2d.drawString(r.className, r.minX + 2, labelY - 3);
        }

        g2d.dispose();
        return output;
    }
}